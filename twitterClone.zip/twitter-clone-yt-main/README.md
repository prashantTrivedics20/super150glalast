## Fullstack Twitter Clone with React, Node, Mongodb, Firebase

![git-twitter](https://user-images.githubusercontent.com/32399333/207771374-49bc685c-610e-4714-8af9-a5995d27489c.png)

<!-- CREDITS -->
<h2 id="credits"> :scroll: Credits</h2>

Oliver G

[![GitHub Badge](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/oliver-gomes)
